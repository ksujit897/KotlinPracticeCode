
var firstCondition=true

if (firstCondition)
{
    print("true hai")
    else
    {
        print("false hai")
    }
}
